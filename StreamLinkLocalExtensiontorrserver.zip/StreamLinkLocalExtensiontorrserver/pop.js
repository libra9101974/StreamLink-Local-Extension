const BACKEND_URL = "http://127.0.0.1:8765/";
const TORRSERVER_STATUS_URL = "http://127.0.0.1:8090/swagger/index.html";

chrome.storage.local.get(["defaultPlayer"], (data) => {
  const player = ["browser", "extension"].includes(data.defaultPlayer) ? data.defaultPlayer : "extension";
  const radio = document.querySelector(`input[value="${player}"]`);
  if (radio) radio.checked = true;
});

document.querySelectorAll('input[name="player"]').forEach((input) => {
  input.addEventListener("change", () => {
    chrome.storage.local.set({ defaultPlayer: input.value });
  });
});

async function checkBackend() {
  const status = document.getElementById("backend-status");
  try {
    const response = await fetch(BACKEND_URL, { signal: AbortSignal.timeout(2500) });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    status.textContent = "Reachable";
    status.classList.add("online");
  } catch {
    status.textContent = "Not reachable — start C:\\StreamLinkLocal\\server.py";
    status.classList.add("offline");
  }
}

checkBackend();


async function checkTorrServer() {
  const status = document.getElementById("torrserver-status");
  try {
    // A successful HTTP response confirms the local TorrServer web UI is reachable.
    await fetch(TORRSERVER_STATUS_URL, { signal: AbortSignal.timeout(2500) });
    status.textContent = "Reachable";
    status.classList.add("online");
  } catch {
    status.textContent = "Not reachable — start TorrServer";
    status.classList.add("offline");
  }
}

checkTorrServer();
