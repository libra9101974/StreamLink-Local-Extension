from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs
import json
import re
import urllib.request
import urllib.error

ACE_URL = "http://127.0.0.1:6878"

class Handler(BaseHTTPRequestHandler):
    def send_json(self, status, data):
        body = json.dumps(data, indent=2).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin",
                         "chrome-extension://bggjndbjpijcfgdcokjfeboceadmlenn")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin",
                         "chrome-extension://bggjndbjpijcfgdcokjfeboceadmlenn")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        if self.path == "/":
            self.send_json(200, {
                "status": "online",
                "backend": "Sid's Local StreamLink",
                "engine": "Ace Stream"
            })
        else:
            self.send_json(404, {"error": "Not found"})

    def do_POST(self):
        if self.path != "/stream":
            self.send_json(404, {"error": "Not found"})
            return

        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 16384:
                self.send_json(400, {"error": "Invalid request size"})
                return

            data = json.loads(self.rfile.read(length))
            magnet = data.get("url", "")

            if not isinstance(magnet, str) or not magnet.startswith("magnet:?"):
                self.send_json(400, {
                    "error": "Send a magnet link in the url field"
                })
                return

            params = parse_qs(urlparse(magnet).query)
            xt_values = params.get("xt", [])
            infohash = None

            for xt in xt_values:
                match = re.fullmatch(r"urn:btih:([a-fA-F0-9]{40})", xt)
                if match:
                    infohash = match.group(1).lower()
                    break

            if not infohash:
                self.send_json(400, {
                    "error": "Magnet must contain a 40-character hexadecimal infohash"
                })
                return

            api_url = (
                f"{ACE_URL}/ace/manifest.m3u8"
                f"?format=json&infohash={infohash}"
            )

            request = urllib.request.Request(
                api_url,
                headers={"Accept": "application/json"}
            )

            with urllib.request.urlopen(request, timeout=60) as response:
                ace_data = json.loads(response.read().decode("utf-8"))

            session = ace_data.get("response")
            if not isinstance(session, dict):
                session = {}
            playback_url = session.get("playback_url")

            if ace_data.get("error") or not playback_url:
                self.send_json(502, {
                    "error": "Ace Stream did not return a playback URL",
                    "details": ace_data.get("error")
                })
                return

            self.send_json(200, {
                "status": "success",
                "engine": "Ace Stream",
                "infohash": infohash,
                "playback_url": playback_url
            })

        except urllib.error.URLError as error:
            self.send_json(502, {
                "error": "Could not contact the local Ace Stream engine",
                "details": str(error.reason)
            })
        except (ValueError, json.JSONDecodeError):
            self.send_json(400, {"error": "Invalid JSON request"})
        except Exception as error:
            self.send_json(500, {"error": str(error)})

    def log_message(self, format, *args):
        print(format % args)

print("Sid's local backend: http://127.0.0.1:8765")
print("Ace Stream engine: http://127.0.0.1:6878")
HTTPServer(("127.0.0.1", 8765), Handler).serve_forever()
