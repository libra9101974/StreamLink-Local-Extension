# Privacy — StreamLink Local

StreamLink Local is an independent local extension build.

- It does not connect to StreamLink cloud services, account APIs, analytics, or proxy endpoints.
- The extension acts only after you choose one of its context-menu commands; it does not start torrent playback automatically on webpages.
- For a magnet link, the extension passes the magnet URI to the local backend you choose: Ace Stream at `http://127.0.0.1:8765/stream` or TorrServer at `http://127.0.0.1:8090/torrents`.
- For a `.torrent` link, the extension downloads the file from the selected link, calculates its BitTorrent v1 info hash locally, and sends a minimal magnet URI to the chosen local backend. The `.torrent` file itself is not uploaded to a cloud service.
- TorrServer is asked to return the chosen video at its local `/play/{hash}/{id}` endpoint; the shared player loads that local URL.

The Ace Stream route requires the separate local backend at `C:\StreamLinkLocal\server.py` and an available Ace Stream engine. The TorrServer route requires TorrServer at `127.0.0.1:8090`. This build supports BitTorrent v1 hashes; pure BitTorrent v2-only magnets are not supported.
