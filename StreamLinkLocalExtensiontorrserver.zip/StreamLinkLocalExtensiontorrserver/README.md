# StreamLink Local — Ace Stream + TorrServer

This is an independent local-only browser extension. It does not use the StreamLink cloud API, proxy, or account.

## Requirements

- Chrome or Microsoft Edge with Manifest V3 extension support.
- For Ace Stream: the local backend at `http://127.0.0.1:8765/` (expected path: `C:\StreamLinkLocal\server.py`) and a running Ace Stream engine.
- For TorrServer: TorrServer running locally at `http://127.0.0.1:8090/`.

Either backend can be used independently.

## Install in Chrome or Edge

1. Extract this ZIP to a normal folder.
2. Open `chrome://extensions` in Chrome or `edge://extensions` in Edge.
3. Turn on **Developer mode**.
4. Choose **Load unpacked** and select the extracted `StreamLinkLocalExtension` folder.
5. Open the extension popup to check the local backend status indicators.

## Use it

1. On a webpage, right-click a **magnet link** or a link whose URL ends in `.torrent`.
2. Choose **Play with StreamLink Local (Ace Stream)** to use the existing Ace Stream backend, or **Play with TorrServer** to use TorrServer.
3. Choose **In-page theater** or **New player tab** from the extension popup. Both routes use the same player handoff.

For `.torrent` links, the extension downloads the selected file only after you choose a context-menu command, calculates the BitTorrent v1 info hash locally, preserves tracker URLs found in the .torrent file, and passes the resulting magnet URI to the chosen local backend. The torrent file is not sent to a cloud service.

## TorrServer notes

- The extension asks TorrServer to add the magnet if it is not already available, then polls for torrent metadata and the file list.
- It selects the largest video file in a browser-friendly format when available.
- For common Chromium-friendly containers (MP4/M4V/WebM/OGV/OGG/MOV), it keeps direct playback via `http://127.0.0.1:8090/play/{hash}/{id}`.
- For other supported video containers (such as MKV/AVI/WMV/FLV/TS/MPEG), it uses TorrServer GStreamer HLS via `http://127.0.0.1:8090/gst/{hash}/master.m3u8?index={id}`. Configure TorrServer GStreamer transcoding to output browser-compatible H.264/AAC as needed.
- Container extensions do not identify the codecs inside a file. An HEVC video inside an MP4 may still need transcoding; this first routing rule uses the container extension as a practical heuristic.
- TorrServer metadata may take up to 60 seconds to become available. If it does not appear, confirm TorrServer is running and the torrent can be loaded.

## Compatibility and troubleshooting

- The extension supports BitTorrent v1 (`btih`) hashes, including Base32 hashes converted to hexadecimal. Pure BitTorrent v2-only magnets are not supported.
- **Ace Stream not reachable:** start `C:\StreamLinkLocal\server.py` and confirm `http://127.0.0.1:8765/` opens locally.
- **TorrServer not reachable:** confirm `http://127.0.0.1:8090/swagger/index.html` opens locally.
- **No menu item:** reload the extension at `chrome://extensions` / `edge://extensions`, then right-click a link (not empty page space).
- **Unsupported link:** use a magnet link or direct HTTP(S) link ending in `.torrent`.

## Files

- `background.js` — context-menu routes, torrent hash calculation, backend requests, player launch.
- `player.html` / `player.js` / `hls.min.js` — shared theater player and HLS playback.
- `injectPlayer.js` — in-page theater overlay.
- `popup.html` / `pop.js` — player choice and local backend status.


Version 1.6.2: HTTP(S) download links no longer need to end in `.torrent`; the downloaded response is validated as a real torrent before use. This supports sites with extensionless or dynamic torrent-download URLs.

Version 1.6.3: TorrServer now routes common browser-friendly containers to direct playback and other video containers to the GStreamer HLS endpoint for transcoding. The Ace Stream route is unchanged.
