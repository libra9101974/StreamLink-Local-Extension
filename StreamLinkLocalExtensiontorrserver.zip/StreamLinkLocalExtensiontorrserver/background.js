// StreamLink Local — playback is routed to a locally installed backend.
// No StreamLink cloud API, proxy, or account is used.

const LOCAL_STREAM_ENDPOINT = "http://127.0.0.1:8765/stream";
const TORRSERVER_BASE_URL = "http://127.0.0.1:8090";
const TORRSERVER_TORRENTS_ENDPOINT = `${TORRSERVER_BASE_URL}/torrents`;
const MAX_TORRENT_BYTES = 20 * 1024 * 1024;

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["defaultPlayer"], (data) => {
    if (!data.defaultPlayer) {
      chrome.storage.local.set({ defaultPlayer: "extension" });
    }
  });

  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "streamlink-local-play",
      title: "Play with StreamLink Local (Ace Stream)",
      contexts: ["link"]
    });
    chrome.contextMenus.create({
      id: "streamlink-torrserver-play",
      title: "Play with TorrServer",
      contexts: ["link"]
    });
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const menuId = info.menuItemId;
  if (!["streamlink-local-play", "streamlink-torrserver-play"].includes(menuId) || !info.linkUrl) return;

  const useTorrServer = menuId === "streamlink-torrserver-play";
  const tabId = tab && tab.id;
  await showToast(tabId, useTorrServer ? "Preparing TorrServer stream…" : "Preparing local Ace Stream…");

  try {
    const settings = await chrome.storage.local.get(["defaultPlayer"]);
    const defaultPlayer = ["browser", "extension"].includes(settings.defaultPlayer)
      ? settings.defaultPlayer
      : "extension";

    const magnet = await linkToMagnet(info.linkUrl);
    const streamData = useTorrServer
      ? await requestTorrServerStream(magnet)
      : await requestLocalStream(magnet);

    if (!streamData.ok) {
      await showToast(tabId, streamData.message);
      triggerBadgeError();
      return;
    }

    await showToast(tabId, streamData.message || (useTorrServer ? "TorrServer ready." : "Local Ace Stream ready."));
    const streamUrl = streamData.url;

    if (defaultPlayer === "browser") {
      const playerUrl = chrome.runtime.getURL(
        `player.html?url=${encodeURIComponent(streamUrl)}&fallback=${encodeURIComponent(tab.url || "about:blank")}`
      );
      await chrome.tabs.create({ url: playerUrl });
      return;
    }

    // In-page theater player. If injection is blocked on this page, use the
    // extension's own player page instead.
    try {
      await chrome.tabs.get(tabId);
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["injectPlayer.js"]
      });

      setTimeout(() => {
        chrome.tabs.sendMessage(tabId, {
          action: "loadStream",
          url: streamUrl
        }).catch(() => {
          const playerUrl = chrome.runtime.getURL(
            `player.html?url=${encodeURIComponent(streamUrl)}&fallback=${encodeURIComponent(tab.url || "about:blank")}`
          );
          chrome.tabs.create({ url: playerUrl }).catch(console.error);
        });
      }, 120);
    } catch (error) {
      console.warn("In-page player unavailable; opening local player tab:", error);
      const playerUrl = chrome.runtime.getURL(
        `player.html?url=${encodeURIComponent(streamUrl)}&fallback=${encodeURIComponent(tab.url || "about:blank")}`
      );
      await chrome.tabs.create({ url: playerUrl });
    }
  } catch (error) {
    console.error("StreamLink Local:", error);
    await showToast(tabId, error && error.message ? error.message : "Could not prepare this link.");
    triggerBadgeError();
  }
});

async function linkToMagnet(linkUrl) {
  if (linkUrl.startsWith("magnet:?")) {
    return normalizeMagnet(linkUrl);
  }

  let parsed;
  try {
    parsed = new URL(linkUrl);
  } catch {
    throw new Error("This link is not a valid magnet or .torrent URL.");
  }

  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    throw new Error("Use a magnet link or an HTTP(S) .torrent link.");
  }

  // Some sites serve torrent files from extensionless or dynamic download URLs.
  // Try downloading any HTTP(S) link and validate its contents as a real torrent;
  // do not rely solely on the URL path ending in ".torrent".

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 20000);
  let response;
  try {
    response = await fetch(linkUrl, {
      method: "GET",
      credentials: "include",
      redirect: "follow",
      signal: controller.signal
    });
  } catch (error) {
    if (error.name === "AbortError") {
      throw new Error("The .torrent download timed out.");
    }
    throw new Error("Could not download the .torrent file. Check the link and your connection.");
  } finally {
    clearTimeout(timeout);
  }

  if (!response.ok) {
    throw new Error(`The .torrent download returned HTTP ${response.status}.`);
  }

  const contentLength = Number(response.headers.get("content-length") || 0);
  if (contentLength > MAX_TORRENT_BYTES) {
    throw new Error("The .torrent file is unusually large (limit: 20 MB).");
  }

  const bytes = new Uint8Array(await response.arrayBuffer());
  if (bytes.length === 0 || bytes.length > MAX_TORRENT_BYTES) {
    throw new Error("The .torrent file is empty or exceeds the 20 MB limit.");
  }

  let torrentMeta;
  try {
    torrentMeta = await getTorrentMetadata(bytes);
  } catch (error) {
    console.warn("StreamLink: HTTP(S) link did not return a valid torrent file:", linkUrl, error);
    throw new Error("This link did not return a valid .torrent file. Some sites use a download page or require a different direct-download link.");
  }
  // Keep tracker URLs from the original .torrent. Sending only the infohash
  // can make torrents fail when DHT/PEX alone cannot discover peers.
  const params = new URLSearchParams({ xt: `urn:btih:${torrentMeta.infoHash}` });
  for (const tracker of torrentMeta.trackers) {
    params.append("tr", tracker);
  }
  return `magnet:?${params.toString()}`;
}

function normalizeMagnet(magnet) {
  let parsed;
  try {
    parsed = new URL(magnet);
  } catch {
    throw new Error("The magnet link is malformed.");
  }

  const topics = parsed.searchParams.getAll("xt");
  const btih = topics.find(topic => /^urn:btih:/i.test(topic));
  if (!btih) {
    throw new Error("This magnet does not contain a BitTorrent v1 hash. Pure v2 magnets are not supported by this local backend.");
  }

  const rawHash = btih.slice("urn:btih:".length);
  let hexHash;
  if (/^[a-f0-9]{40}$/i.test(rawHash)) {
    hexHash = rawHash.toLowerCase();
  } else if (/^[a-z2-7]{32}$/i.test(rawHash)) {
    hexHash = base32ToHex(rawHash);
  } else {
    throw new Error("The magnet contains an unrecognized BitTorrent hash.");
  }

  // The local Python backend currently expects a 40-character hexadecimal
  // btih hash. Keep the outgoing magnet minimal and deterministic.
  return `magnet:?xt=urn:btih:${hexHash}`;
}

function base32ToHex(input) {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  let bits = "";
  for (const char of input.toUpperCase()) {
    const value = alphabet.indexOf(char);
    if (value < 0) throw new Error("Invalid Base32 BitTorrent hash.");
    bits += value.toString(2).padStart(5, "0");
  }
  let output = "";
  for (let i = 0; i + 4 <= bits.length; i += 4) {
    output += parseInt(bits.slice(i, i + 4), 2).toString(16);
  }
  if (output.length !== 40) throw new Error("The magnet's Base32 hash has an invalid length.");
  return output;
}

// Decode the bencoded .torrent document, hash the exact raw bytes of its
// "info" dictionary, and retain tracker URLs for the generated magnet.
async function getTorrentMetadata(bytes) {
  let cursor = 0;
  let infoSpan = null;

  function readByteString() {
    const lengthStart = cursor;
    while (cursor < bytes.length && bytes[cursor] >= 48 && bytes[cursor] <= 57) cursor++;
    if (cursor === lengthStart || bytes[cursor] !== 58) {
      throw new Error("The .torrent file is not valid bencode.");
    }
    const lengthText = new TextDecoder("ascii").decode(bytes.subarray(lengthStart, cursor));
    const length = Number(lengthText);
    cursor++; // colon
    if (!Number.isSafeInteger(length) || length < 0 || cursor + length > bytes.length) {
      throw new Error("The .torrent file contains an invalid byte-string length.");
    }
    const value = bytes.subarray(cursor, cursor + length);
    cursor += length;
    return value;
  }

  function parseValue(depth = 0) {
    if (depth > 100 || cursor >= bytes.length) {
      throw new Error("The .torrent file is truncated or nested too deeply.");
    }

    const marker = bytes[cursor];

    if (marker >= 48 && marker <= 57) {
      return readByteString();
    }

    if (marker === 105) { // i<number>e
      cursor++;
      const start = cursor;
      while (cursor < bytes.length && bytes[cursor] !== 101) cursor++;
      if (cursor >= bytes.length) throw new Error("Invalid integer in .torrent file.");
      const value = new TextDecoder("ascii").decode(bytes.subarray(start, cursor));
      if (!/^-?\d+$/.test(value)) throw new Error("Invalid integer in .torrent file.");
      cursor++;
      return Number(value);
    }

    if (marker === 108) { // list
      cursor++;
      const list = [];
      while (cursor < bytes.length && bytes[cursor] !== 101) {
        list.push(parseValue(depth + 1));
      }
      if (cursor >= bytes.length) throw new Error("Unterminated list in .torrent file.");
      cursor++;
      return list;
    }

    if (marker === 100) { // dictionary
      cursor++;
      const dict = Object.create(null);
      while (cursor < bytes.length && bytes[cursor] !== 101) {
        const keyBytes = readByteString();
        const key = new TextDecoder("utf-8").decode(keyBytes);
        const valueStart = cursor;
        const value = parseValue(depth + 1);
        if (depth === 0 && key === "info") {
          infoSpan = { start: valueStart, end: cursor };
        }
        dict[key] = value;
      }
      if (cursor >= bytes.length) throw new Error("Unterminated dictionary in .torrent file.");
      cursor++;
      return dict;
    }

    throw new Error("The link did not return a valid .torrent file.");
  }

  const root = parseValue();
  if (cursor !== bytes.length) {
    // Trailing whitespace or bytes are not valid in a standard .torrent file.
    throw new Error("The .torrent file contains unexpected trailing data.");
  }
  if (!infoSpan || infoSpan.end <= infoSpan.start) {
    throw new Error("The .torrent file has no valid info dictionary.");
  }

  const digest = await crypto.subtle.digest("SHA-1", bytes.subarray(infoSpan.start, infoSpan.end));
  const infoHash = Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");

  const trackers = [];
  const seenTrackers = new Set();
  const decoder = new TextDecoder("utf-8", { fatal: false });
  const addTracker = value => {
    if (!(value instanceof Uint8Array)) return;
    const tracker = decoder.decode(value).trim();
    if (!/^https?:\/\//i.test(tracker) && !/^udp:\/\//i.test(tracker)) return;
    if (!seenTrackers.has(tracker)) {
      seenTrackers.add(tracker);
      trackers.push(tracker);
    }
  };

  if (root && typeof root === "object" && !Array.isArray(root)) {
    addTracker(root.announce);
    const announceList = root["announce-list"];
    if (Array.isArray(announceList)) {
      for (const tier of announceList) {
        if (Array.isArray(tier)) tier.forEach(addTracker);
        else addTracker(tier);
      }
    }
  }

  return { infoHash, trackers: trackers.slice(0, 30) };
}

// TorrServer route. The Ace Stream function below remains unchanged.
async function requestTorrServerStream(magnet) {
  const hash = getHexBtihFromMagnet(magnet);

  // Reuse a torrent already known to TorrServer; otherwise add it once.
  let torrent = null;
  try {
    torrent = await torrServerPost({ action: "get", hash }, 8000);
  } catch {
    // A missing torrent commonly returns an API error; the add request below handles it.
  }

  let addError = null;
  if (!selectTorrServerVideo(torrent)) {
    try {
      await torrServerPost({ action: "add", link: magnet }, 20000);
    } catch (error) {
      // If TorrServer says the torrent is already present, continue polling its metadata.
      // A connection failure, however, should be reported immediately.
      if (error && /Cannot reach TorrServer|request timed out at 127\.0\.0\.1:8090/i.test(error.message || "")) {
        throw error;
      }
      addError = error;
    }
  }

  // TorrServer may need time to fetch metadata before its file list is available.
  const deadline = Date.now() + 60000;
  let lastError = addError;
  while (Date.now() < deadline) {
    try {
      torrent = await torrServerPost({ action: "get", hash }, 8000);
      const selected = selectTorrServerVideo(torrent);
      if (selected) {
        // Use direct playback for common Chromium-friendly containers. For formats
        // that commonly need transcoding (for example MKV/AVI/WMV), use TorrServer's
        // GStreamer HLS endpoint so the player receives browser-friendly H.264 output.
        const url = selected.browserPlayable
          ? `${TORRSERVER_BASE_URL}/play/${hash}/${selected.file.id}`
          : `${TORRSERVER_BASE_URL}/gst/${hash}/master.m3u8?index=${selected.file.id}`;
        return {
          ok: true,
          url,
          message: selected.browserPlayable
            ? "TorrServer ready — opening direct video playback."
            : "TorrServer ready — opening GStreamer HLS transcoding."
        };
      }
    } catch (error) {
      lastError = error;
    }
    await new Promise(resolve => setTimeout(resolve, 1500));
  }

  const detail = lastError && /127\.0\.0\.1:8090/i.test(lastError.message) ? ` ${lastError.message}` : "";
  throw new Error(`TorrServer did not provide a video file within 60 seconds. Check that TorrServer is running and the torrent metadata is available.${detail}`);
}

function getHexBtihFromMagnet(magnet) {
  let parsed;
  try {
    parsed = new URL(magnet);
  } catch {
    throw new Error("The magnet link could not be read for TorrServer.");
  }
  const btih = parsed.searchParams.getAll("xt").find(topic => /^urn:btih:/i.test(topic));
  const hash = btih ? btih.slice("urn:btih:".length) : "";
  if (!/^[a-f0-9]{40}$/i.test(hash)) {
    throw new Error("TorrServer requires a normalized 40-character BitTorrent v1 hash.");
  }
  return hash.toLowerCase();
}

async function torrServerPost(payload, timeoutMs = 10000) {
  let response;
  try {
    response = await fetch(TORRSERVER_TORRENTS_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(timeoutMs)
    });
  } catch (error) {
    if (error && error.name === "TimeoutError") {
      throw new Error("TorrServer request timed out at 127.0.0.1:8090.");
    }
    throw new Error("Cannot reach TorrServer at 127.0.0.1:8090. Make sure TorrServer is running.");
  }

  const text = await response.text();
  let data = null;
  if (text.trim()) {
    try {
      data = JSON.parse(text);
    } catch {
      if (payload.action === "get") {
        throw new Error("TorrServer returned an unreadable torrent response.");
      }
    }
  }

  if (!response.ok) {
    const reason = data && (data.error || data.message);
    throw new Error(reason || `TorrServer returned HTTP ${response.status}.`);
  }
  if (data && typeof data === "object" && (data.error || data.Error)) {
    throw new Error(data.error || data.Error);
  }
  return data;
}

function selectTorrServerVideo(torrent) {
  if (!torrent || typeof torrent !== "object") return null;

  let files = Array.isArray(torrent.file_stats) ? torrent.file_stats : [];
  if (!files.length && typeof torrent.data === "string") {
    try {
      const parsedData = JSON.parse(torrent.data);
      files = parsedData && parsedData.TorrServer && Array.isArray(parsedData.TorrServer.Files)
        ? parsedData.TorrServer.Files
        : [];
    } catch {
      files = [];
    }
  }

  const videoExtensions = new Set(["mp4", "m4v", "webm", "ogv", "ogg", "mov", "mkv", "avi", "wmv", "flv", "ts", "mpg", "mpeg", "m2ts"]);
  const browserExtensions = new Set(["mp4", "m4v", "webm", "ogv", "ogg", "mov"]);
  const videos = files.filter(file => {
    if (!file || !Number.isInteger(Number(file.id)) || Number(file.id) < 0) return false;
    const path = String(file.path || file.name || "");
    const match = path.match(/\.([a-z0-9]+)$/i);
    return Boolean(match && videoExtensions.has(match[1].toLowerCase()));
  }).map(file => {
    const path = String(file.path || file.name || "");
    const extension = (path.match(/\.([a-z0-9]+)$/i) || ["", ""])[1].toLowerCase();
    return {
      file: { ...file, id: Number(file.id) },
      browserPlayable: browserExtensions.has(extension),
      length: Number(file.length) || 0
    };
  });

  if (!videos.length) return null;
  // Prefer formats Chromium normally plays, then choose the largest likely main feature.
  videos.sort((a, b) => Number(b.browserPlayable) - Number(a.browserPlayable) || b.length - a.length);
  return videos[0];
}

async function requestLocalStream(magnet) {
  let response;
  try {
    response = await fetch(LOCAL_STREAM_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: magnet }),
      signal: AbortSignal.timeout(20000)
    });
  } catch (error) {
    console.error("Local backend request failed:", error);
    throw new Error("Cannot reach the local backend at 127.0.0.1:8765. Start C:\\StreamLinkLocal\\server.py and try again.");
  }

  let data = {};
  try {
    data = await response.json();
  } catch {
    throw new Error(`The local backend returned an unreadable response (HTTP ${response.status}).`);
  }

  if (!response.ok || !data.playback_url) {
    throw new Error(data.message || data.error || `Local streaming failed (HTTP ${response.status}).`);
  }

  return {
    ok: true,
    url: data.playback_url,
    message: "Local Ace Stream ready."
  };
}

function triggerBadgeError() {
  chrome.action.setBadgeText({ text: "!" });
  chrome.action.setBadgeBackgroundColor({ color: "#FF3B30" });
  setTimeout(() => chrome.action.setBadgeText({ text: "" }), 4000);
}

async function showToast(tabId, message) {
  if (typeof tabId !== "number") return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: (msg) => {
        const existing = document.getElementById("streamlink-local-toast");
        if (existing) existing.remove();
        const toast = document.createElement("div");
        toast.id = "streamlink-local-toast";
        toast.textContent = msg;
        const isError = /cannot|failed|error|not supported|not valid|does not|no valid|timed out|http \d/i.test(msg);
        Object.assign(toast.style, {
          position: "fixed",
          bottom: "30px",
          right: "30px",
          maxWidth: "min(520px, 80vw)",
          background: "rgba(28, 28, 30, 0.97)",
          color: "#fff",
          padding: "14px 20px",
          borderRadius: "12px",
          zIndex: "2147483647",
          fontSize: "14px",
          lineHeight: "1.4",
          boxShadow: "0 8px 24px rgba(0,0,0,0.4)",
          borderLeft: `4px solid ${isError ? "#FF3B30" : "#0a84ff"}`,
          fontFamily: "system-ui, sans-serif"
        });
        document.documentElement.appendChild(toast);
        setTimeout(() => toast.remove(), 5000);
      },
      args: [message]
    });
  } catch {
    // Some browser pages (chrome://, extension stores, PDFs) disallow scripts.
  }
}
